g_api_key="xxxxxx"
g_secret_key="xxxxxx"




g_sub_uid = 123456

g_account_id = 123456

